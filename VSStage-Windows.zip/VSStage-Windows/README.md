# VS Stage para Windows

Soundcheck virtual / playback multipista para bandas — versão **Windows** do app Android.
Usa o **mesmo motor de áudio em C++** (Signalsmith Stretch, Quantized Jump, loop, pads, EQ, limiter, buses Banda/Click/Guia),
interface em Dear ImGui (SDL2 + OpenGL), saída de áudio via **WASAPI** (miniaudio) e MIDI via WinMM (RtMidi).
Funciona 100% offline.

## Como obter o .exe

### Opção A — GitHub Actions (não precisa instalar nada)
1. Crie um repositório no GitHub (pode ser privado) e envie **esta pasta inteira** (inclusive `.github/`).
2. Aba **Actions → "Compilar VS Stage (Windows)" → Run workflow** (também roda sozinho a cada push).
3. Ao terminar (~10 min na primeira vez), baixe o artefato **VSStage-windows-x64**: ele contém `VSStage.exe` (arquivo único, sem DLLs).

### Opção B — compilar no seu PC
1. Instale o [MSYS2](https://www.msys2.org) e, no terminal "MSYS2 MINGW64":
   `pacman -S --needed mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-ninja git`
2. Dê dois cliques em `build_windows.bat` (baixa o SDL2 sozinho; precisa de internet na 1ª vez).
3. O executável sai em `build\VSStage.exe`.

> O Windows pode mostrar o aviso do SmartScreen ("aplicativo não reconhecido") porque o `.exe` não é assinado digitalmente: *Mais informações → Executar assim mesmo*.

## Usando

Os dados ficam em `%APPDATA%\VSStage` (biblioteca, áudios copiados, ajustes). Para levar tudo para outro PC/celular use **pacotes `.vsstage`**.

| Aba | O que faz |
|---|---|
| **Palco** | Transporte, seções (salto quantizado no próximo compasso), loop, BPM e Tom em tempo real, pads, mixer com **todas as faixas lado a lado** (faders verticais, VU, Mute/Solo, barramento Banda/Click/Guia), master com EQ de 3 bandas e limiter. |
| **Biblioteca** | Importa arquivos/pasta (ou arraste para a janela). O papel de cada faixa (Click, Guia, Bateria, Baixo…) e o título são reconhecidos pelo nome do arquivo; você confere antes de confirmar. O BPM e o 1º tempo são detectados automaticamente na primeira vez que a música é carregada. |
| **Setlists** | Ordem das músicas com **ajustes por dia** (tom, BPM, pad, faixas mudas/ganhos). Exporta/importa pacote `.vsstage` **compatível com o app Android** (inclusive o áudio). |
| **Saída** | Escolha da interface de áudio, nº de canais (até 16), buffer, modo exclusivo, matriz de saídas (Banda L/R, Click, Guia, Click+Guia por canal). |
| **Pedais** | Entrada MIDI + *MIDI Learn* para play/pause, stop, seções, loop, tom, BPM, pad e troca de música. |

Atalhos no Palco: `Espaço` play/pause · `←`/`→` seção anterior/próxima · `↑`/`↓` BPM (com `Shift`: tom) · `L` loop · `Esc` stop · `PgUp`/`PgDn` música do setlist.
Duplo clique num fader volta para 0 dB.

## Latência e interfaces de áudio

- Saída WASAPI, 48 kHz internos. Em **modo exclusivo** com buffer de 128–256 quadros a latência típica fica em poucos ms.
- Interfaces USB class-compliant aparecem com seus canais na aba Saída. Para **ASIO** use um driver ASIO→WASAPI (FlexASIO, por exemplo) ou o modo WASAPI do driver do fabricante — ASIO nativo não é usado.
- Com Tom ou BPM alterados o motor processa time-stretch (mais CPU); se houver estalos, aumente o buffer.

## Limitações conhecidas

- Formatos de áudio: **WAV, MP3 e FLAC**. M4A/AAC não são lidos nesta versão (converta antes).
- Os áudios são carregados na RAM em float32 (~90 MB por faixa de 4 min em estéreo): para músicas com 16+ faixas longas, prefira PC com 16 GB.
- A troca de música no setlist recarrega as faixas (não é *gapless*).
- Esta versão **não foi testada em hardware Windows real** por quem a escreveu (a lógica, o motor e a interface foram testados em Linux com saída de áudio simulada). Se algo falhar no seu PC, envie a mensagem/captura de tela.

## Estrutura

```
engine/      motor de áudio (idêntico ao Android)
core/        biblioteca JSON, pacotes .vsstage, mapeador de nomes, player, áudio (miniaudio), MIDI
src/         interface (Dear ImGui) e janela (SDL2)
tests/       testes sem placa de som (mapeador, importação, carga, transporte, pacotes)
third_party/ miniaudio, Dear ImGui, nlohmann/json, miniz, RtMidi, Signalsmith Stretch
```

Testes: `VSS_AUDIO_BACKEND=null build\core_test.exe` (usa saída simulada).
Capturas de tela automáticas (Linux, para desenvolvimento): `VSStage --shots pasta`.
